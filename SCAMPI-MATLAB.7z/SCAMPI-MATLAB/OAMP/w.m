W = recover_hadamard[rp, fs, rp2]
  